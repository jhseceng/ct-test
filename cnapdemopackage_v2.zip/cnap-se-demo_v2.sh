## Set Up ##
printf "\nSetting up prereqs...\n"
#!/bin/bash
DG="\033[1;30m"
RD="\033[0;31m"
NC="\033[0;0m"
LB="\033[1;34m"
env_up(){
    echo -e "$LB\n"
    echo -e "Initializing environment templates$NC"
    sudo yum -y install unzip
    #setup aws cli 2
    sudo yum remove awscli -y
    sudo rm -f /usr/local/bin/aws
    sudo rm -f /usr/local/bin/aws_completer
    curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
    unzip awscliv2.zip
    sudo ./aws/install
    sudo ln -s /usr/local/aws-cli/v2/2.7.27/bin/aws /usr/local/bin/aws
    sudo ln -s /usr/local/aws-cli/v2/2.7.27/bin/aws_completer /usr/local/bin/
    ## Set Vars ##
    ACCOUNT_ID=$(aws sts get-caller-identity | jq -r '.Account')
    BUCKET_NAME="$(cat /tmp/environment.txt | cut -c -8 | tr _ - | tr '[:upper:]' '[:lower:]')-templatebucket"
    REGION_CODE="us-west-2"
    permissionBoundary="arn:aws:iam::$ACCOUNT_ID:policy/BoundaryForAdministratorAccess"
    CFExtLogRoleName="$(cat /tmp/environment.txt | cut -c -8 | tr _ - | tr '[:upper:]' '[:lower:]')-CFExtLogRole"
    CFExtExecRoleName="$(cat /tmp/environment.txt | cut -c -8 | tr _ - | tr '[:upper:]' '[:lower:]')-CFExtExecRole"
    aws configure set region us-west-2
    ## Push Templates to S3 ##
    cd /home/ec2-user
    mkdir s3bucket
    unzip -d s3bucket s3bucket.zip
    aws s3api create-bucket --bucket $BUCKET_NAME --region $REGION_CODE --create-bucket-configuration LocationConstraint=$REGION_CODE
    cd s3bucket
    aws s3 cp . s3://$BUCKET_NAME --recursive
    ## Fetch policy files ##

    curl https://raw.githubusercontent.com/jhseceng/cwp-container-lab/master/templates/CFExtExecPolicy.json -o CFExtExecPolicy.json
    curl https://raw.githubusercontent.com/jhseceng/cwp-container-lab/master/templates/CFExtLogPolicy.json -o CFExtLogPolicy.json
    curl https://raw.githubusercontent.com/jhseceng/cwp-container-lab/master/templates/CFExtLogTrustPolicy.json -o CFExtLogTrustPolicy.json
    curl https://raw.githubusercontent.com/jhseceng/cwp-container-lab/master/templates/CFExtExecTrustPolicy.json -o CFExtExecTrustPolicy.json
    ## Create CF Ext Log Role ##
    CFExtLogRole=$(aws iam create-role --role-name $CFExtLogRoleName --assume-role-policy-document file://CFExtLogTrustPolicy.json)
    CFExtLogRoleArn=$(echo $CFExtLogRole | jq -r '.Role.Arn')
    printf "\nCFExtLogRoleArn = $CFExtLogRoleArn"
    ### Create Policy
    CFExtLogPolicy=$(aws iam create-policy --policy-name CFExtLogPolicy --policy-document file://CFExtLogPolicy.json)
    CFExtLogPolicyArn=$(echo $CFExtLogPolicy | jq -r '.Policy.Arn')
    printf "\nCFExtLogPolicyArn = $CFExtLogPolicyArn\n"
    ### Attach Policy
    aws iam attach-role-policy --policy-arn $CFExtLogPolicyArn --role-name $CFExtLogRoleName
    ## Create CF Ext Execution Role ##
    CFExtExecRole=$(aws iam create-role --role-name $CFExtExecRoleName --permissions-boundary $permissionBoundary --assume-role-policy-document file://CFExtExecTrustPolicy.json)
    CFExtExecRoleArn=$(echo $CFExtExecRole | jq -r '.Role.Arn')
    printf "\nCFExtExecRoleArn = $CFExtExecRoleArn"
    ### Create Policy
    CFExtExecPolicy=$(aws iam create-policy --policy-name CFExtExecPolicy --policy-document file://CFExtExecPolicy.json)
    CFExtExecPolicyArn=$(echo $CFExtExecPolicy | jq -r '.Policy.Arn')
    printf "\nCFExtExecPolicyArn = $CFExtExecPolicyArn\n"
    ### Attach Policy
    aws iam attach-role-policy --policy-arn $CFExtExecPolicyArn --role-name $CFExtExecRoleName
    ## Activate CF Resource Types ##
    ### awsqs kubernetes apply
    applyActivate=$(aws cloudformation activate-type \
    --public-type-arn arn:aws:cloudformation:us-west-2::type/resource/408988dff9e863704bcc72e7e13f8d645cee8311/AWSQS-Kubernetes-Resource \
    --type RESOURCE \
    --logging-config LogRoleArn=$CFExtLogRoleArn,LogGroupName=cloudformation/registry/awsqs-kubernetes-resource \
    --execution-role-arn $CFExtExecRoleArn)
    applyArn=$(echo $applyActivate | jq -r '.Arn')
    printf "AWSQS::Kubernetes::Resource Token = $applyArn"
    ### awsqs kubernetes helm
    helmActivate=$(aws cloudformation activate-type \
    --public-type-arn arn:aws:cloudformation:us-west-2::type/resource/408988dff9e863704bcc72e7e13f8d645cee8311/AWSQS-Kubernetes-Helm \
    --type RESOURCE \
    --logging-config LogRoleArn=$CFExtLogRoleArn,LogGroupName=cloudformation/registry/awsqs-kubernetes-resource \
    --execution-role-arn $CFExtExecRoleArn)
    helmArn=$(echo $helmActivate | jq -r '.Arn')
    printf "\nAWSQS::Kubernetes::Helm Token = $helmArn"
    ### awsqs eks cluster
    clusterActivate=$(aws cloudformation activate-type \
    --public-type-arn arn:aws:cloudformation:us-west-2::type/resource/408988dff9e863704bcc72e7e13f8d645cee8311/AWSQS-EKS-Cluster \
    --type RESOURCE \
    --logging-config LogRoleArn=$CFExtLogRoleArn,LogGroupName=cloudformation/registry/awsqs-kubernetes-resource \
    --execution-role-arn $CFExtExecRoleArn)
    clusterArn=$(echo $clusterActivate | jq -r '.Arn')
    printf "\nAWSQS::EKS::Cluster Token = $clusterArn\n"
    ## Stand Up Environment
    echo -e "$LB\n"
    echo -e "Standing up environment$NC"
    aws cloudformation create-stack --stack-name cwp-demo-stack --template-url https://$BUCKET_NAME.s3-$REGION_CODE.amazonaws.com/cwp-lab-entrypoint.yaml --parameters  ParameterKey=FalconClientID,ParameterValue=$CLIENT_ID ParameterKey=FalconClientSecret,ParameterValue=$CLIENT_SECRET ParameterKey=S3Bucket,ParameterValue=$BUCKET_NAME ParameterKey=CrowdStrikeCloud,ParameterValue=$CS_CLOUD  ParameterKey=FalconCID,ParameterValue="${CS_CID}" --capabilities CAPABILITY_NAMED_IAM CAPABILITY_IAM CAPABILITY_AUTO_EXPAND --region $REGION_CODE
    echo -e "The Cloudformation stack will take 20-30 minutes to complete$NC"
    echo -e "\n\nCheck the status at any time with the command \n\naws cloudformation describe-stacks --stack-name cwp-demo-stack --region $REGION_CODE$NC\n\n"
    sleep 5
    id=$(aws ec2 describe-instances --region us-west-2 --filters "Name=tag:Name,Values=Startup" --query "Reservations[0].Instances[].InstanceId" --output text)
    aws ec2 terminate-instances --region us-west-2 --instance-ids $id
}
env_down(){
    echo -e "$RD\n"
    echo -e "Tearing down environment$NC"
    aws cloudformation delete-stack --stack-name horizon-demo-stack --region $REGION_CODE
    env_destroyed
}
help(){
    echo "./demo {up|down|help}"
}
all_done(){
    echo -e "$LB"
    echo '  __                        _'
    echo ' /\_\/                   o | |             |'
    echo '|    | _  _  _    _  _     | |          ,  |'
    echo '|    |/ |/ |/ |  / |/ |  | |/ \_|   |  / \_|'
    echo ' \__/   |  |  |_/  |  |_/|_/\_/  \_/|_/ \/ o'
    echo -e "$NC"
}
api_keys(){
    echo -e "$NC"
    echo ''
    echo ' Create an OAuth2 key pair with permissions for the Streaming API and Hosts API'
    echo '     | Service                           | Read | Write |'
    echo '     | -------                           |----- | ----- |'
    echo '     | Sensor Download                   | x    |       |'
    echo '     | Falcon Images Download            | x    |       |'
    echo '     | Falcon Container Image            | x    |   x   |'
    echo '     | Kubernetes Protection Agent       |      |   x   |'
    echo '     | -------                           |----- | ----- |'
    echo ''
    echo ' CS_CLOUD Should be one of the following us-1, us-2 or eu-1'
    echo -e "$NC"
}
env_destroyed(){
    echo -e "$RD"
    echo ' ___                              __,'
    echo '(|  \  _  , _|_  ,_        o     /  |           __|_ |'
    echo ' |   ||/ / \_|  /  | |  |  |    |   |  /|/|/|  |/ |  |'
    echo '(\__/ |_/ \/ |_/   |/ \/|_/|/    \_/\_/ | | |_/|_/|_/o'
    echo -e "$NC"
}
if [ -z $1 ]
then
    echo "You must specify an action."
    help
    exit 1
fi
if [[ "$1" == "up" || "$1" == "reload" ]]

then
    api_keys
    for arg in "$@"
    do
        if [[ "$arg" == *--client_id=* ]]
        then
            CLIENT_ID=${arg/--client_id=/}
        fi
        if [[ "$arg" == *--client_secret=* ]]
        then
            CLIENT_SECRET=${arg/--client_secret=/}
        fi
        if [[ "$arg" == *--cs_cloud=* ]]
        then
            CS_CLOUD=${arg/--cs_cloud=/}
        fi
                if [[ "$arg" == *--cid=* ]]
        then
            CS_CID=${arg/--cid=/}
        fi
        if [[ "$arg" == *--unique_id=* ]]
        then
            UNIQUE_ID=${arg/--unique_id=/}
        fi
        if [[ "$arg" == *--owner=* ]]
        then
            OWNER_ID="${arg/--owner=/}"
        fi
        if [[ "$arg" == *--trusted=* ]]
        then
            TRUSTED_IP="${arg/--trusted=/}"
        fi
        if [[ "$arg" == *--baseurl=* ]]
        then
            BASE_URL="${arg/--baseurl=/}"
        fi
    done
    if [ -z "$CLIENT_ID" ]
    then
        read -p "Falcon API Client ID: " CLIENT_ID
    fi
    if [ -z "$CLIENT_SECRET" ]
    then
        read -p "Falcon API Client SECRET: " CLIENT_SECRET
    fi
    if [ -z "$CS_CLOUD" ]
    then
        read -p "CrowdStrike Cloud: us-1, us-2 or eu-1  " CS_CLOUD
    fi
        if [ -z "$CS_CID" ]
    then
        read -p "CrowdStrike CID  " CS_CID
    fi
    if [ -z "$UNIQUE_ID" ]
    then
        read -p "Unique Identifier: " UNIQUE_ID
    fi
    # if [ -z "$OWNER_ID" ]
    # then
    #     read -p "Presenter name: " OWNER_ID
    # fi
    if [ -z "$TRUSTED_IP" ]
    then
        read -p "Your external IP Address (for SSH connection, CIDR format): " TRUSTED_IP
    fi
    if [ -z "$BASE_URL" ]
    then
        BASE=""
    else
        BASE=" -var falcon_base_url='$BASE_URL'"
    fi
fi
if [[ "$1" == "up" ]]
then
    env_up
elif [[ "$1" == "down" ]]
then
    env_down
elif [[ "$1" == "help" ]]
then
    help
else
    echo "Invalid action specified"
fi

