#!/bin/bash
UNIQUE=$(cat /tmp/environment.txt | cut -c -8 | tr _ - | tr '[:upper:]' '[:lower:]')
cd /home/ec2-user
/home/ec2-user/build/falcon-start.sh up --unique_id="$UNIQUE" --trusted="$(curl -s http://ipinfo.io/ip)/32" --client_id 3317c345398f4e978eb8f97c003fa34b --client-secret 6gWBy23rvFMU8J5L1G7qioSdTHXl4Qacx9jpO0AD --cs_cloud us-1 --cid '865621D267734600B9D3705BECC1DFAA-84'